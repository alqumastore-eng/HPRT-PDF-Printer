package com.example.hprtprinter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var pdfUri: Uri? = null
    private var pageCount = 0
    private var socket: BluetoothSocket? = null
    private var printerName = "غير متصل"
    private lateinit var status: TextView
    private lateinit var fileLabel: TextView
    private lateinit var pageInput: EditText
    private lateinit var connectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        askBluetoothPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 30, 24, 24); setBackgroundColor(Color.rgb(247,249,252)) }
        val title = TextView(this).apply { text = "طباعة PDF – HPRT N41BT"; textSize = 23f; setTextColor(Color.rgb(20,40,70)); gravity = Gravity.CENTER; setPadding(0,12,0,24) }
        status = TextView(this).apply { text = "حالة الطابعة: غير متصلة"; textSize = 16f; gravity = Gravity.CENTER; setPadding(8,16,8,16) }
        connectButton = Button(this).apply { text = "الاتصال بطابعة Bluetooth"; setOnClickListener { choosePrinter() } }
        val choose = Button(this).apply { text = "اختيار ملف PDF"; setOnClickListener { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(i, 100) } }
        fileLabel = TextView(this).apply { text = "لم يتم اختيار ملف"; textSize = 15f; setPadding(8,18,8,18); gravity = Gravity.CENTER }
        pageInput = EditText(this).apply { hint = "رقم الصفحة (اتركه فارغاً لطباعة الكل)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; textSize = 15f }
        val print = Button(this).apply { text = "طباعة PDF"; setOnClickListener { printPdf() } }
        val specs = TextView(this).apply { text = "مقاس الملصق: 90 × 120 مم\nالدقة: 203 DPI – أبيض وأسود"; textSize = 14f; gravity = Gravity.CENTER; setPadding(8,22,8,12) }
        root.addView(title); root.addView(status); root.addView(connectButton); root.addView(choose); root.addView(fileLabel); root.addView(pageInput); root.addView(print); root.addView(specs)
        setContentView(root)
    }


    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            pdfUri = uri
            inspectPdf(uri)
        }
    }

    private fun askBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 20)
        }
    }

    @Suppress("MissingPermission")
    private fun choosePrinter() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { askBluetoothPermission(); return }
        val devices = adapter.bondedDevices.toList().sortedBy { it.name ?: "" }
        if (devices.isEmpty()) { message("لا توجد طابعة مقترنة. اربط N41BT من إعدادات Bluetooth أولاً."); return }
        val labels = devices.map { "${it.name ?: "جهاز بلا اسم"}  (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("اختر طابعة HPRT").setItems(labels) { _, which -> connect(devices[which]) }.setNegativeButton("إلغاء", null).show()
    }

    @Suppress("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        status.text = "جارٍ الاتصال بـ ${device.name}..."
        worker.execute {
            try {
                socket?.close()
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect(); socket = s; printerName = device.name ?: "HPRT"
                runOnUiThread { status.text = "متصل: $printerName" }
            } catch (e: Exception) { runOnUiThread { status.text = "فشل الاتصال: ${e.localizedMessage}" } }
        }
    }

    private fun inspectPdf(uri: Uri) {
        try {
            val fd = contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("تعذر فتح الملف")
            PdfRenderer(fd).use { renderer -> pageCount = renderer.pageCount }
            fileLabel.text = "تم اختيار PDF – عدد الصفحات: $pageCount"
        } catch (e: Exception) { message("تعذر قراءة PDF: ${e.localizedMessage}") }
    }

    private fun printPdf() {
        val uri = pdfUri ?: run { message("اختر ملف PDF أولاً"); return }
        if (socket?.isConnected != true) { message("اتصل بالطابعة أولاً"); return }
        val requested = pageInput.text.toString().trim().toIntOrNull()
        if (requested != null && (requested < 1 || requested > pageCount)) { message("رقم الصفحة غير صحيح"); return }
        status.text = "جارٍ تجهيز الطباعة..."
        worker.execute {
            try {
                val fd = contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("تعذر فتح PDF")
                PdfRenderer(fd).use { renderer ->
                    val pages = if (requested == null) 0 until renderer.pageCount else listOf(requested - 1)
                    for (index in pages) {
                        val page = renderer.openPage(index)
                        val bmp = Bitmap.createBitmap(720, 960, Bitmap.Config.ARGB_8888)
                        val canvas = android.graphics.Canvas(bmp); canvas.drawColor(Color.WHITE)
                        val scale = minOf(720f / page.width, 960f / page.height)
                        val w = (page.width * scale).toInt(); val h = (page.height * scale).toInt()
                        val left = (720 - w) / 2; val top = (960 - h) / 2
                        page.render(bmp, android.graphics.Rect(left, top, left + w, top + h), null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        page.close()
                        val bytes = toMonoBytes(bmp); bmp.recycle()
                        val out = socket?.outputStream ?: throw IOException("انقطع اتصال الطابعة")
                        out.write("SIZE 90 mm,120 mm\r\nGAP 2 mm,0 mm\r\nDENSITY 8\r\nCLS\r\nBITMAP 0,0,90,960,0,".toByteArray(Charsets.US_ASCII))
                        out.write(bytes); out.write("\r\nPRINT 1,1\r\n".toByteArray(Charsets.US_ASCII)); out.flush()
                        Thread.sleep(900)
                    }
                }
                runOnUiThread { status.text = "اكتملت أوامر الإرسال للطابعة" }
            } catch (e: Exception) { runOnUiThread { status.text = "تعذرت الطباعة: ${e.localizedMessage}" } }
        }
    }

    // 720 dots wide = 90 bytes per row at 8 dots/mm; TSPL BITMAP uses MSB-first monochrome bytes.
    private fun toMonoBytes(bitmap: Bitmap): ByteArray {
        val out = ByteArrayOutputStream(90 * 960)
        for (y in 0 until 960) {
            for (bx in 0 until 90) {
                var value = 0
                for (bit in 0..7) {
                    val pixel = bitmap.getPixel(bx * 8 + bit, y)
                    val luminance = (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000
                    if (luminance < 170) value = value or (1 shl (7 - bit))
                }
                out.write(value)
            }
        }
        return out.toByteArray()
    }

    private fun message(text: String) = AlertDialog.Builder(this).setMessage(text).setPositiveButton("حسناً", null).show()
    override fun onDestroy() { try { socket?.close() } catch (_: Exception) {}; worker.shutdown(); super.onDestroy() }
}
